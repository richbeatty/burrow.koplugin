## 0.2.1 alpha - 2026-08-05

- Replaced the exact KOReader version lock with a minimum-version and last-tested policy.
- Allowed newer KOReader releases and nightlies to load with a one-time warning.
- Added known-incompatible version ranges for targeted future blocks.
- Added dependency-aware module states, feature-level preflight, degraded-mode notices, and automatic quarantine after apply-time failures.
- Added a Features menu action to clear module quarantine and retry after restart.
- Moved the ProjectTitle-derived core library runtime and KOReader method captures out of `main.lua` into guarded `burrow_library.lua`.
- Reduced `main.lua` to prerequisite checks, compatibility evaluation, phased loading, and plugin-class creation.

## 0.2.0 alpha - 2026-08-04

- Removed the required `patches/2-burrow-bootstrap.lua` installation.
- Added a plugin-owned phased module loader in `burrow_loader.lua`.
- Converted all 17 bundled interface files into idempotent modules.
- Replaced `userpatch.registerPatchPluginFunc` registration with direct Burrow class application.
- Preserved a compatibility manifest so an old 0.1.x bootstrap can remain harmless for one transitional startup.
- Added a one-time notice when the obsolete bootstrap is detected.
- Centralized Burrow and embedded Store version metadata in `burrow_version.lua`.
- Moved complete custom-icon installation into the plugin itself.
- Updated installation, upgrade, removal, and architecture documentation for the plugin-only package.

## 0.1.9 alpha - 2026-08-04

- Fixed return-to-library tile corruption after opening a series book and returning with the back gesture.
- Rendered the return icon as an opaque, uncached image so partial redraws cannot expose stale reader pixels through SVG transparency.
- Detached and recursively freed the previous return tile before rebuilding it, preventing stale image-widget references.

## 0.1.8 alpha - 2026-08-04

- Added a Burrow-owned square return-to-library SVG instead of relying on KOReader's shared Home icon.
- Clamped return-tile icon and padding dimensions to the actual available tile area.
- Prevented distortion or clipping when mosaic slots are reused after leaving the reader.

## Burrow 0.1.7 Alpha

- Removed the experimental rounded top-tab replacement after it caused menu crashes on Android.
- Restored KOReader's native transparent, theme-aware top-bar icons and native tab behavior.
- Kept Burrow's rounded Quick Settings cards and footer without changing live top-tab widget trees.

## 0.1.4 alpha - 2026-08-04

- Restored direct access to the Store download queue from the root, facet, and catalog menus.
- Added an empty-queue message instead of silently doing nothing.
- Kept the download queue accessible in text-only catalogs by using the Store menu consistently.
- Excluded JPEG, PNG, SVG, WebP, GIF, BMP, and AVIF cover resources from downloadable book formats.
- Applied rounded outlined styling to every top-level menu tab in both the file manager and reader, with a filled active tab.
- Kept the special rounded Quick Settings panel while making the top-tab treatment global.

## 0.1.3 alpha - 2026-08-04

- Renamed the main plugin class and private state from the inherited library namespace to Burrow.
- Renamed `ptutil.lua` and `ptdbg.lua` to `burrow_util.lua` and `burrow_debug.lua`.
- Renamed the embedded Store module tree to `burrow_store/`.
- Renamed internal patch files and manifest entries to Burrow-oriented names.
- Migrated cover, top-bar, Home/Store, and selected-catalog setting keys to Burrow-owned names.
- Added one-time migration to `burrow_library.sqlite3` and `burrow_store.lua` while retaining legacy files as backups.
- Isolated legacy names to migration, conflict detection, removal instructions, and legal acknowledgements.
- Updated menus, About text, documentation, package metadata, and internal Store versioning for Burrow 0.1.3.

## 0.1.2 alpha - 2026-08-04

- Changed the honey badger artwork to a black monochrome KOReader icon so it follows light and dark mode dynamically.
- Added **Show Home and Store labels**.
- Added **Hide labels when no Store catalogs are configured**.
- When labels are hidden, Burrow keeps the centered page indicators and removes the unused divider and navigation row.
- Stopped the bootstrap from overwriting existing generic KOReader or user-customized icons.
- Corrected Burrow icon cleanup when plugin settings are deleted.
- Updated package documentation and version information.

## 0.1.1 alpha - 2026-08-04

- Kept Burrow visible when a prerequisite or embedded Store load fails.
- Added visible prerequisite and Store error reporting.
- Added the supplied honey badger artwork.
